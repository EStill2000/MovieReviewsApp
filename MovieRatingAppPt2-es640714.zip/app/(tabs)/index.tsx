//Elias Stillahn ID:640714 11/23/2025

//I used non-copyrighted images for the splash and logo
import { useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { SQLiteProvider, useSQLiteContext, type SQLiteDatabase } from "expo-sqlite";
import * as WebBrowser from 'expo-web-browser';
import * as React from 'react';
import { Alert, Keyboard, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, TouchableWithoutFeedback, View } from 'react-native';


async function migrateDBIfNeeded(db: SQLiteDatabase){
await db.execAsync(`CREATE TABLE IF NOT EXISTS Reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  movieTitle TEXT,
  movieRating INTEGER,
  movieImage TEXT
  );
  `);
}

function SQLDB() {
  return (
  <SQLiteProvider databaseName="movieRatings.db" onInit={migrateDBIfNeeded}>
      <RootStack />
    </SQLiteProvider>
  );
}


function HomeScreen() {

  const navigation = useNavigation();
  const db = useSQLiteContext();
  const [reviews, setReviews] = React.useState([]);

  const fetchReviews = React.useCallback(() => {
    async function refetch() {
      const results = await db.getAllAsync(
        "SELECT id, movieTitle, movieRating, movieImage FROM Reviews ORDER BY id DESC;"
      );
      setReviews(results);
    }
    refetch();
  }, [db]);
//automatically shows reviews if the homescreen is visible
   React.useEffect(() => {
      const unsubscribe = navigation.addListener("focus", fetchReviews);
      return unsubscribe;
    }, [navigation, fetchReviews]);



//fetch current movies in the database
  React.useEffect(() => {
  fetchReviews();
}, [fetchReviews]);

  return (
    <ScrollView>
    <SafeAreaView>
      {/* title */}
      {/* <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Movie Ratings</Text>
      </View> */}

      {/* add review button */}
      <View>
        <Pressable style={styles.addButtonHomePage}
          onPress={() => {
            navigation.navigate("Add");
          }}><Text style={styles.addButtonText}>Add Review</Text>
        </Pressable>
      </View>



        {/* button for wiping db for testing  */}
      {/* <Pressable
        onPress={async () => {
          await db.execAsync("DELETE FROM Reviews;");
          await db.execAsync("DELETE FROM sqlite_sequence WHERE name='Reviews';");
          setReviews([]);
        }}>
        <Text>Wipe DB</Text>
      </Pressable> */}



      {/* reviews */}
      <View style={styles.headerRow}>
        <Text style={styles.headerText}>Poster</Text>
        <Text style={styles.headerText}>Movie Title</Text>
        <Text style={styles.headerText}>Rating</Text>
      </View>
      <View style={styles.divider2} />
      
      {reviews.map(({ id, movieTitle, movieRating, movieImage }) => (
      <View key={id}>
        <View style={styles.row}>
          <Image source={{ uri: movieImage }} style={styles.poster} />

          <View style={styles.titleContainer1}>
           <Text style={styles.titleText1}>{movieTitle}</Text>
          </View>

          <View style={styles.ratingContainer}>
            {/* used an emoji */}
            <Text style={styles.star}>⭐</Text>
            <Text style={styles.rating}>{movieRating}</Text>
          </View>
        </View>

        <View style={styles.divider} />
      </View>
      ))}


      {/* link to imdb */}
      <View style={styles.compareCritics}>
          <Text style={styles.compareText}>Compare to critics online </Text>
          {/* made the image pressable to take you to imdb.com */}
          <Pressable onPress={() => WebBrowser.openBrowserAsync('https://www.imdb.com/')}><Image source={require('../../assets/images/imdb.png')} style={styles.compareImage}/></Pressable>
          <Text style={styles.compareText}>Click IMDB image above.</Text>
      </View>


    </SafeAreaView>
    </ScrollView>
  );
}

function AddReview() {
  const db = useSQLiteContext();
  const navigation = useNavigation();

  //validation
  const [movieTitle, setTitle] = React.useState('');
  const [movieRating, setRating] = React.useState('');
  const [movieImage, setImage] = React.useState('');
  const [inputError, setError] = React.useState('');

  const checkEmpty = async () => {
    if(!movieTitle.trim() || !movieRating.trim() || !movieImage.trim()){
      setError('Not all fields are filled out.');
      return;
    }

    //resets our error if one was there
    setError('');

    await db.runAsync(
    "INSERT INTO Reviews (movieTitle, movieRating, movieImage) VALUES (?, ?, ?);",
    movieTitle,
    parseInt(movieRating),
    movieImage
  );
    //will send you back to the home page after validation.
    navigation.goBack();

  }


  //used image picker from https://docs.expo.dev/versions/latest/sdk/imagepicker/
const chooseImage = async () => {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
//make sure there is permission granted from the user
  if(!permission.granted) {
    Alert.alert("Permission required");
    return;
  }

  let result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsEditing: true,
    aspect: [3, 4],
    quality: 1,
  });
//if image is chosen add it 
  if (!result.canceled) {
    setImage(result.assets[0].uri);
  }

}

//check if image was chosen for validation for user
let imageText = null
if(movieImage){
  imageText = ( <Text style={styles.titleText2}>Image Chosen</Text>);
}


return (
  //Iphone doesnt have the done button on a keypad so i added a feature to dismiss the keybaord when you touch outside the keypad
  <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
<SafeAreaView>
      {/* title */}
      {/* <View style={styles.titleContainer}>
        <Text style={styles.titleText}>Add Review</Text>
      </View> */}

      {/* Movie Title */}
      
      <View style={styles.inputStyles}>
        <Text style={styles.inputStylesTitles}>Movie Title</Text>
        <TextInput  style={styles.inputBackground}
          placeholder="Enter the Movie Name"
          placeholderTextColor="gray"
          keyboardType="default"
          value={movieTitle}
          onChangeText={setTitle}
        />
      </View>

        {/* Movie Rating */}
      <View style={styles.inputStyles}>
        <Text style={styles.inputStylesTitles}>Movie Rating (1 - 10)</Text>
        <TextInput  style={styles.inputBackground}
          placeholder="Enter the Movie Rating"
          placeholderTextColor="gray"
          keyboardType="numeric"
          value={movieRating}
          onChangeText={setRating}
        />
      </View>

    {/* Movie Poster Image */}
      <View style={styles.inputStyles}>
        <Text style={styles.inputStylesTitles}>movie Poster Image</Text>
        {/* <TextInput  style={styles.inputBackground}
          placeholder="Enter the Movie Image"
          placeholderTextColor="gray"
          value={movieImage}
          onChangeText={setImage} */}
          
        {/* /> */}
        <Pressable style={styles.imageDesign} onPress={chooseImage}>
         <Text style={styles.imageInputText}>Pick an image</Text> 
         
         </Pressable>
          
        {imageText}
        
      </View>
      
      {inputError && (
        <Text style={{ 
          color: 'red', 
          textAlign: 'center', 
          marginTop: 10 }}>
          {inputError}
        </Text>
      )}


      {/* submit button*/}
      <View>
        <Pressable style={styles.addButtonHomePage}
          onPress={checkEmpty}><Text style={styles.addButtonText}>Add Review</Text>
        </Pressable>
      </View>

      {/* cancel button*/}
      {/* Realized the navigation gives both the web and mobile a back arrow at the top of the screen */}
        {/* <View>
        <Pressable style={styles.HomeButtonReviewPage}
          onPress={() => {
            navigation.goBack();
          }}><Text style={styles.addButtonText}>Home</Text>
        </Pressable>
        </View> */}


    </SafeAreaView>
    </TouchableWithoutFeedback>
);
}

const Stack = createNativeStackNavigator();
function RootStack() {
  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#990000',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 26,
        },
      }}
    >
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: 'Movie Reviews'
        }}
      />
      <Stack.Screen
        name="Add"
        component={AddReview}
        options={{
          title: 'Add Review',
        }}
      />
    </Stack.Navigator>
  );
}


export default function App() {
  return (<SQLDB />);
}

//I really need to work on combining styles
const styles = StyleSheet.create({
  imageInputText: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 24,
    padding: 10,
  },
  imageDesign: {
    backgroundColor: '#E2DBDB',
    padding: 3,
    fontSize: 20,
    
  },
  compareText: {
    marginLeft: 30,
    marginBottom: 5,
    fontWeight: 'bold'
  },
  compareImage: {
    marginLeft: 75,
    marginRight: 'auto',
    width: 75, 
    height: 50,
  },
  compareCritics: {
    bottom: -10,
    left: 80

  },
  HomeButtonReviewPage: {
    height: 30,
    width: 75,
    backgroundColor: '#1A0B0B',
    borderRadius: 10,
    marginTop: 100,
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  inputBackground: {
    backgroundColor: '#E2DBDB',
    padding: 3,
    fontSize: 20
  },
inputStylesTitles: {
    marginLeft: -25,
    fontWeight: 'bold',
    fontSize: 16
  },
  inputStyles: {
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 50,
    borderWidth: 1,
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 50,
    paddingRight: 50,
     
    
  },
  addButtonText: {
    color: 'white',
    margin: 'auto',
    fontSize: 20
  },
  addButtonHomePage: {
    height: 40,
    width: 125,
    backgroundColor: '#1A0B0B',
    borderRadius: 10,
    marginTop: 30,
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  titleText: {
    color: 'white',
    marginLeft: 'auto',
    marginRight: 'auto',
    fontSize: 26,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#990000',
    height: 100,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 178,
    width: 290,
    bottom: 0,
    left: 0,
    position: 'absolute',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 5,
  },
  poster: {
    width: 60,
    height: 90,
    borderRadius: 4,
    marginRight: 10,
  },
  titleContainer1: {
    flex: 1,
    justifyContent: 'center',
  },
  titleText1: {
    fontSize: 18,
    textAlign: 'center',
  
  },
  ratingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 50,
  },
  star: {
    fontSize: 24,
    marginBottom: -6,
  },
  rating: {
    fontSize: 20,
  },
  divider: {
    height: 1,
    backgroundColor: '#ccc',
    marginVertical: 5,
  },
  divider2: {
    height: 1,
    backgroundColor: 'black',
    marginVertical: 5,
  },
  headerRow: {
    flexDirection: 'row',
  },
  headerText: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingTop: 20,
    fontSize: 20
  },
  titleText2: {
    fontSize: 18,
    textAlign: 'center',
    color: "green"
  },

});
